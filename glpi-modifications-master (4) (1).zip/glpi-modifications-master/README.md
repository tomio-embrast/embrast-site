# Announcement:

# I'm suspending this plugin development due the changes of new GLPI 9.5, including the new builtin dashboard. The new structure demands a large rewrite of code, which i can't do at moment.

Estou suspendendo o desenvolvimento deste plug-in devido às alterações do novo GLPI 9.5, incluindo o novo painel interno. A nova estrutura exige uma grande reescrita de código, o que não posso fazer no momento.


Screenshots: https://sourceforge.net/projects/glpithemes/

- Antes de instalar remova qualquer versão anterior do plugin.
- Depois de descompactar o arquivo, renomeie a pasta para "mod".


- Before install remove any previous versions of plugin.
- Rename the unziped folder to "mod".
